
export enum TicketType {
  EARLY_BIRD = 'EARLY_BIRD',
  STANDARD = 'STANDARD',
  VIP = 'VIP'
}

export interface TicketOption {
  type: TicketType;
  name: string;
  price: number;
  description: string;
  features: string[];
  popular?: boolean;
}

export interface RegistrationData {
  fullName: string;
  email: string;
  ticketType: TicketType;
  cardNumber: string;
  expiryDate: string;
  cvv: string;
}

export interface EventSchedule {
  time: string;
  title: string;
  speaker: string;
  role: string;
}
