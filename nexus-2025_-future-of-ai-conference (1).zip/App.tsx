
import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Pricing } from './components/Pricing';
import { RegistrationForm } from './components/RegistrationForm';
import { Schedule } from './components/Schedule';
import { Footer } from './components/Footer';
import { ChatBot } from './components/ChatBot';
import { TicketType } from './types';

const App: React.FC = () => {
  const [selectedTicket, setSelectedTicket] = useState<TicketType | null>(null);
  const [isRegistered, setIsRegistered] = useState(false);

  const scrollToRegistration = (ticketType?: TicketType) => {
    if (ticketType) setSelectedTicket(ticketType);
    const element = document.getElementById('register');
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  if (isRegistered) {
    return (
      <div className="min-h-screen bg-[#030712] flex flex-col items-center justify-center p-6 text-center">
        <div className="glass p-12 rounded-3xl max-w-2xl border-emerald-500/30">
          <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 className="text-4xl font-extrabold mb-4">Registration Complete!</h1>
          <p className="text-slate-400 text-lg mb-8">
            Welcome to the future. A confirmation email with your digital pass and QR code has been sent to your inbox. 
            We can't wait to see you at Nexus 2025.
          </p>
          <button 
            onClick={() => setIsRegistered(false)}
            className="px-8 py-3 bg-indigo-600 hover:bg-indigo-500 transition-colors rounded-full font-semibold"
          >
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="fixed inset-0 -z-10 bg-[#030712]">
        <div className="absolute top-0 -left-4 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute top-0 -right-4 w-72 h-72 bg-indigo-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse delay-700"></div>
        <div className="absolute -bottom-8 left-20 w-72 h-72 bg-pink-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-pulse delay-1000"></div>
      </div>

      <Navbar onRegisterClick={() => scrollToRegistration()} />
      
      <main>
        <Hero onCtaClick={() => scrollToRegistration()} />
        
        <section id="pricing" className="py-24 px-6">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-4">Choose Your Experience</h2>
              <p className="text-slate-400 max-w-2xl mx-auto">
                Select the ticket that fits your journey. From students to executives, 
                we have a path tailored for everyone.
              </p>
            </div>
            <Pricing onSelect={(type) => scrollToRegistration(type)} />
          </div>
        </section>

        <section id="schedule" className="py-24 bg-slate-900/50">
          <div className="max-w-7xl mx-auto px-6">
            <Schedule />
          </div>
        </section>

        <section id="register" className="py-24 px-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold mb-4">Register Now</h2>
              <p className="text-slate-400">Secure your spot at the year's most anticipated AI event.</p>
            </div>
            <RegistrationForm 
              initialTicket={selectedTicket} 
              onSuccess={() => setIsRegistered(true)} 
            />
          </div>
        </section>
      </main>

      <Footer />
      <ChatBot />
    </div>
  );
};

export default App;
