
import { TicketType, TicketOption, EventSchedule } from './types';

export const TICKETS: TicketOption[] = [
  {
    type: TicketType.EARLY_BIRD,
    name: "Early Bird",
    price: 199,
    description: "Limited availability for the pioneers.",
    features: [
      "Full access to all sessions",
      "Digital certificate",
      "Network with attendees",
      "Coffee & Lunch included"
    ]
  },
  {
    type: TicketType.STANDARD,
    name: "Standard Pass",
    price: 299,
    description: "The complete conference experience.",
    features: [
      "All Early Bird features",
      "Workshop access",
      "Swag bag (Premium)",
      "Access to session recordings"
    ],
    popular: true
  },
  {
    type: TicketType.VIP,
    name: "VIP Elite",
    price: 599,
    description: "Premium access and executive networking.",
    features: [
      "All Standard features",
      "VIP Dinner with speakers",
      "Front-row reserved seating",
      "One-on-one mentor session"
    ]
  }
];

export const SCHEDULE: EventSchedule[] = [
  { time: "09:00 AM", title: "Opening Keynote: The AGI Horizon", speaker: "Dr. Sarah Chen", role: "Head of AI, Nexus Labs" },
  { time: "11:00 AM", title: "Generative Workflows in Enterprise", speaker: "Marcus Thorne", role: "CTO, FutureSoft" },
  { time: "02:00 PM", title: "Ethics & Regulation: A Global Panel", speaker: "Elena Rodriguez", role: "Policy Advisor" },
  { time: "04:30 PM", title: "Future of Human-AI Collaboration", speaker: "Dr. James Wilson", role: "Research Scientist" }
];
