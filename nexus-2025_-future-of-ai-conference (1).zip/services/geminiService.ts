
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getAIResponse = async (userMessage: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userMessage,
      config: {
        systemInstruction: `You are an AI assistant for the 'Nexus 2025: Future of AI Conference'. 
        Event Details: 
        - Date: November 15-16, 2025.
        - Location: TechHub Plaza, San Francisco.
        - Ticket Prices: Early Bird ($199), Standard ($299), VIP ($599).
        - Speakers: Dr. Sarah Chen, Marcus Thorne, Elena Rodriguez.
        Answer questions concisely and professionally. If someone asks about registration, guide them to the form.`,
      },
    });
    return response.text || "I'm sorry, I couldn't process that. Please try again.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm currently offline, but feel free to explore the event details below!";
  }
};
