
import React from 'react';

interface HeroProps {
  onCtaClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onCtaClick }) => {
  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20 px-6 overflow-hidden">
      <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
        <div className="relative z-10 text-center lg:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-sm font-medium mb-6">
            <span className="flex h-2 w-2 rounded-full bg-indigo-500 animate-ping"></span>
            November 15-16, 2025 • San Francisco
          </div>
          <h1 className="text-6xl md:text-8xl font-black leading-tight tracking-tighter mb-6">
            THE FUTURE <br />
            <span className="gradient-text">IS ARTIFICIAL</span>
          </h1>
          <p className="text-lg md:text-xl text-slate-400 mb-10 max-w-xl">
            Join 5,000+ innovators, engineers, and visionaries for a two-day immersion into 
            the technologies that are reshaping our world. 
          </p>
          <div className="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start">
            <button 
              onClick={onCtaClick}
              className="w-full sm:w-auto px-8 py-4 gradient-bg rounded-2xl font-bold text-lg shadow-2xl shadow-indigo-500/40 hover:translate-y-[-2px] transition-all"
            >
              Secure My Spot
            </button>
            <button className="w-full sm:w-auto px-8 py-4 glass rounded-2xl font-bold text-lg hover:bg-white/10 transition-all">
              Watch Trailer
            </button>
          </div>
          
          <div className="mt-12 flex items-center gap-6 justify-center lg:justify-start">
            <div className="flex -space-x-3">
              {[1, 2, 3, 4].map((i) => (
                <img 
                  key={i} 
                  src={`https://picsum.photos/seed/${i + 50}/100/100`} 
                  className="w-10 h-10 rounded-full border-2 border-[#030712] object-cover" 
                  alt="Attendee" 
                />
              ))}
            </div>
            <p className="text-sm text-slate-400">
              <span className="text-white font-bold">4.8k+</span> already registered
            </p>
          </div>
        </div>

        <div className="relative hidden lg:block">
          <div className="relative z-10 float">
            <img 
              src="https://picsum.photos/seed/tech/800/800" 
              alt="Tech Visual" 
              className="rounded-3xl shadow-2xl shadow-indigo-500/10 border border-white/10"
            />
            <div className="absolute -bottom-6 -left-6 glass p-6 rounded-2xl border-white/20">
              <div className="text-xs text-slate-400 mb-1 uppercase tracking-widest font-bold">Live Stream</div>
              <div className="text-2xl font-bold text-white">4k+ Concurrent</div>
            </div>
          </div>
          <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-indigo-500/20 blur-[100px] rounded-full"></div>
        </div>
      </div>
    </section>
  );
};
