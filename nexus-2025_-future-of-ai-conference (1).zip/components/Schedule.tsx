
import React from 'react';
import { SCHEDULE } from '../constants';

export const Schedule: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold mb-4">Event Schedule</h2>
        <p className="text-slate-400">Two days packed with insights, networking, and workshops.</p>
      </div>

      <div className="space-y-8">
        {SCHEDULE.map((item, idx) => (
          <div key={idx} className="flex gap-6 group">
            <div className="w-24 shrink-0 pt-1 text-right">
              <span className="text-sm font-bold text-indigo-400 block">{item.time}</span>
            </div>
            
            <div className="relative pb-12 grow">
              {idx !== SCHEDULE.length - 1 && (
                <div className="absolute left-[-21px] top-6 w-[2px] h-full bg-slate-800"></div>
              )}
              <div className="absolute left-[-26px] top-2 w-3 h-3 rounded-full bg-indigo-500 border-4 border-[#030712] group-hover:scale-125 transition-transform"></div>
              
              <div className="glass p-6 rounded-2xl group-hover:bg-white/5 transition-all">
                <h3 className="text-xl font-bold mb-2 text-white">{item.title}</h3>
                <div className="flex items-center gap-3">
                  <img src={`https://picsum.photos/seed/${idx + 100}/40/40`} className="w-8 h-8 rounded-full" alt={item.speaker} />
                  <div>
                    <span className="text-sm font-medium text-slate-300">{item.speaker}</span>
                    <span className="text-xs text-slate-500 block">{item.role}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
