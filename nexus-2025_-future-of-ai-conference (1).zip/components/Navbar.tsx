
import React, { useState, useEffect } from 'react';

interface NavbarProps {
  onRegisterClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onRegisterClick }) => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'glass py-4' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 gradient-bg rounded-lg flex items-center justify-center font-bold text-white shadow-lg shadow-indigo-500/20">N</div>
          <span className="text-xl font-bold tracking-tight">NEXUS<span className="text-indigo-400">2025</span></span>
        </div>
        
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-300">
          <a href="#pricing" className="hover:text-white transition-colors">Pricing</a>
          <a href="#schedule" className="hover:text-white transition-colors">Schedule</a>
          <a href="#about" className="hover:text-white transition-colors">Speakers</a>
        </div>

        <button 
          onClick={onRegisterClick}
          className="px-6 py-2.5 gradient-bg rounded-full text-sm font-bold shadow-xl shadow-indigo-500/20 hover:scale-105 active:scale-95 transition-all"
        >
          Get Tickets
        </button>
      </div>
    </nav>
  );
};
