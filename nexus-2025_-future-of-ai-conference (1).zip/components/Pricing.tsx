
import React from 'react';
import { TICKETS } from '../constants';
import { TicketType } from '../types';

interface PricingProps {
  onSelect: (type: TicketType) => void;
}

export const Pricing: React.FC<PricingProps> = ({ onSelect }) => {
  return (
    <div className="grid md:grid-cols-3 gap-8">
      {TICKETS.map((ticket) => (
        <div 
          key={ticket.type}
          className={`relative group rounded-3xl p-8 flex flex-col transition-all duration-300 hover:translate-y-[-8px] ${
            ticket.popular ? 'bg-slate-900 border-2 border-indigo-500/50 shadow-2xl shadow-indigo-500/10' : 'glass'
          }`}
        >
          {ticket.popular && (
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-indigo-500 rounded-full text-xs font-bold uppercase tracking-wider text-white">
              Most Popular
            </div>
          )}
          
          <div className="mb-8">
            <h3 className="text-2xl font-bold mb-2">{ticket.name}</h3>
            <p className="text-slate-400 text-sm leading-relaxed">{ticket.description}</p>
          </div>

          <div className="mb-8">
            <span className="text-5xl font-black">${ticket.price}</span>
            <span className="text-slate-500 ml-2">/ pass</span>
          </div>

          <ul className="space-y-4 mb-10 flex-grow">
            {ticket.features.map((feature, idx) => (
              <li key={idx} className="flex items-start gap-3 text-sm text-slate-300">
                <svg className="w-5 h-5 text-indigo-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M5 13l4 4L19 7" />
                </svg>
                {feature}
              </li>
            ))}
          </ul>

          <button 
            onClick={() => onSelect(ticket.type)}
            className={`w-full py-4 rounded-xl font-bold transition-all ${
              ticket.popular 
                ? 'gradient-bg text-white shadow-lg shadow-indigo-500/20' 
                : 'bg-white/10 hover:bg-white/20 text-white'
            }`}
          >
            Select {ticket.name}
          </button>
        </div>
      ))}
    </div>
  );
};
