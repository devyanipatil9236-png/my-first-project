
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="py-20 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 gradient-bg rounded-lg flex items-center justify-center font-bold text-white">N</div>
              <span className="text-xl font-bold tracking-tight">NEXUS<span className="text-indigo-400">2025</span></span>
            </div>
            <p className="text-slate-400 max-w-sm mb-8">
              The premier global gathering for AI researchers, developers, and visionaries. 
              Bridging the gap between theory and transformation.
            </p>
            <div className="flex gap-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="w-10 h-10 glass rounded-xl flex items-center justify-center cursor-pointer hover:bg-white/10 transition-colors">
                  <div className="w-4 h-4 bg-slate-400 rounded-sm"></div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-bold mb-6">Conference</h4>
            <ul className="space-y-4 text-slate-400 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Speakers</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Agenda</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Venues</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Sponsors</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6">Resources</h4>
            <ul className="space-y-4 text-slate-400 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Code of Conduct</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4 text-slate-500 text-sm">
          <p>© 2025 Nexus AI Conference. All rights reserved.</p>
          <p>Built for the future.</p>
        </div>
      </div>
    </footer>
  );
};
