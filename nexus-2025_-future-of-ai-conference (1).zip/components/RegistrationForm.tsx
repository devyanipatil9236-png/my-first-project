
import React, { useState, useEffect } from 'react';
import { TicketType, RegistrationData } from '../types';
import { TICKETS } from '../constants';

interface RegistrationFormProps {
  initialTicket: TicketType | null;
  onSuccess: () => void;
}

export const RegistrationForm: React.FC<RegistrationFormProps> = ({ initialTicket, onSuccess }) => {
  const [formData, setFormData] = useState<RegistrationData>({
    fullName: '',
    email: '',
    ticketType: initialTicket || TicketType.STANDARD,
    cardNumber: '',
    expiryDate: '',
    cvv: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (initialTicket) {
      setFormData(prev => ({ ...prev, ticketType: initialTicket }));
    }
  }, [initialTicket]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsSubmitting(false);
    onSuccess();
  };

  const selectedTicketInfo = TICKETS.find(t => t.type === formData.ticketType);

  return (
    <div className="glass p-8 md:p-12 rounded-[2rem] border-white/5 shadow-2xl">
      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-400 ml-1">Full Name</label>
            <input 
              required
              type="text" 
              name="fullName"
              placeholder="John Doe"
              value={formData.fullName}
              onChange={handleChange}
              className="w-full bg-slate-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500 transition-all"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-400 ml-1">Email Address</label>
            <input 
              required
              type="email" 
              name="email"
              placeholder="john@example.com"
              value={formData.email}
              onChange={handleChange}
              className="w-full bg-slate-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500 transition-all"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-semibold text-slate-400 ml-1">Selected Ticket</label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {TICKETS.map((ticket) => (
              <button
                key={ticket.type}
                type="button"
                onClick={() => setFormData(prev => ({ ...prev, ticketType: ticket.type }))}
                className={`px-4 py-3 rounded-xl border text-sm font-bold transition-all ${
                  formData.ticketType === ticket.type 
                    ? 'bg-indigo-500/20 border-indigo-500 text-indigo-300' 
                    : 'bg-slate-900/50 border-white/10 text-slate-400 hover:border-white/20'
                }`}
              >
                {ticket.name} (${ticket.price})
              </button>
            ))}
          </div>
        </div>

        <div className="pt-8 border-t border-white/10">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold">Payment Details</h3>
            <div className="flex gap-2">
              <div className="h-6 w-10 bg-slate-800 rounded flex items-center justify-center text-[10px] font-bold text-slate-500">VISA</div>
              <div className="h-6 w-10 bg-slate-800 rounded flex items-center justify-center text-[10px] font-bold text-slate-500">MC</div>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-400 ml-1">Card Number</label>
              <input 
                required
                type="text" 
                name="cardNumber"
                placeholder="0000 0000 0000 0000"
                value={formData.cardNumber}
                onChange={handleChange}
                maxLength={19}
                className="w-full bg-slate-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500 transition-all"
              />
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-400 ml-1">Expiry Date</label>
                <input 
                  required
                  type="text" 
                  name="expiryDate"
                  placeholder="MM/YY"
                  value={formData.expiryDate}
                  onChange={handleChange}
                  className="w-full bg-slate-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500 transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-400 ml-1">CVV</label>
                <input 
                  required
                  type="text" 
                  name="cvv"
                  placeholder="123"
                  value={formData.cvv}
                  onChange={handleChange}
                  className="w-full bg-slate-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500 transition-all"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="pt-8">
          <div className="bg-slate-900 rounded-2xl p-6 mb-8 flex items-center justify-between">
            <div>
              <div className="text-sm text-slate-400">Total amount to pay</div>
              <div className="text-2xl font-bold">${selectedTicketInfo?.price}.00</div>
            </div>
            <div className="text-xs text-emerald-500 font-bold bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
              SECURE CHECKOUT
            </div>
          </div>

          <button 
            disabled={isSubmitting}
            type="submit"
            className={`w-full py-4 rounded-2xl font-black text-xl flex items-center justify-center gap-3 transition-all ${
              isSubmitting 
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
                : 'gradient-bg text-white shadow-2xl shadow-indigo-500/30 hover:scale-[1.01]'
            }`}
          >
            {isSubmitting ? (
              <>
                <svg className="animate-spin h-6 w-6 text-slate-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
              </>
            ) : (
              `Pay $${selectedTicketInfo?.price} & Register`
            )}
          </button>
          <p className="text-center text-xs text-slate-500 mt-4">
            By registering, you agree to our Terms of Service and Privacy Policy. 
            Payment processed via simulated secure channel.
          </p>
        </div>
      </form>
    </div>
  );
};
